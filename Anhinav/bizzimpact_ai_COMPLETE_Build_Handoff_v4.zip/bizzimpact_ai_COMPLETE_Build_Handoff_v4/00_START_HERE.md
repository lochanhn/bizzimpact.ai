# bizzimpact.ai — COMPLETE CROSS-MODEL BUILD HANDOFF v4.0

**Primary upload artifact:** `bizzimpact_ai_COMPLETE_Build_Handoff_v4.zip`  
**Project:** bizzimpact.ai (formerly documented as impact.ai)  
**Contest:** University of Maryland AI for Small Business Hack-a-thon, Fall 2026  
**Development target NOW:** Phase 1 — authentication + approved onboarding + hybrid AI-tool discovery  
**Future phases:** Phase 2 — evidence-based evaluation/review metrics; Phase 3 — multi-tool compatibility, integration and adoption assistance.

## What to upload and paste

1. Upload **this ZIP alone** to a coding-capable ChatGPT, Claude, or Gemini environment.
2. Paste the complete content of **`01_MASTER_BUILD_PROMPT.md`**. It is also duplicated as `PASTE_THIS_PROMPT.txt` so the user can access it without opening Markdown.
3. Instruct the AI to **extract and inspect every active root document and `references/` file**. The AI should not treat archived ZIPs as competing specifications.
4. Require it to create real project files, run appropriate build and tests, and report objectively what it could and couldn't test.
5. Configure secrets **only in secure environment variables**, never in the chat or repository.

If the AI can't extract ZIPs, unpack locally and provide the **active top-level files plus `references/`, `fixtures/`, `prompts_for_later/`** individually. Supporting visuals and historical archives are nonessential for implementation.

## Core product idea
Build a **discovery, evaluation, and adoption advisor for existing AI tools** for nontechnical small-business owners. The app does **not** itself need to be a restaurant inventory predictor, an HVAC receptionist, or a marketing content generator. Phase 1 supports business onboarding, reusable profiles, a catalog-only baseline, natural-language needs, a hybrid catalog+live-web discovery engine, structured source-backed product profiles, deduplication, and a handoff to later phases.

## Authoritative documents (read in this order)

1. `01_MASTER_BUILD_PROMPT.md` — exact implementation instructions for Phase 1.
2. `02_SOURCE_OF_TRUTH.md` — base precedence; see **`11_V4_DECISIONS_AND_OVERRIDES.md`** for brand and packaging-specific overrides.
3. `03_PRODUCT_VISION_AND_PHASES.md` — whole product and subsequent module boundaries.
4. `references/AI_for_Small_Business_Hackathon_Fall_2026_The Challenge.pdf` — official challenge (business problem, rules, deadlines, IP language, scoring).
5. `references/AI_Small_Business_Discovery_Onboarding_Spec_v1.html` — APPROVED ONBOARDING; use embedded machine-readable `questionnaire-spec`.
6. `fixtures/questionnaire_approved_v1.json` — convenience extraction of approved questionnaire (reconcile with HTML if different).
7. `references/impact_ai_Onboarding_and_Discovery_Architecture_v2.html` — full discovery design; use embedded `architecture-spec` where present.
8. `04_DISCOVERY_IMPLEMENTATION_CONTRACT.md`, `05_UI_UX_CONTRACT.md`, `references/impact_ai_discovery_openapi_v2.yaml`, `references/impact_ai_discovery_schema_v2.sql` — build interfaces.
9. `06_OPENROUTER_COST_SECURITY.md`, `.env.example` — secrets and credit protection.
10. `07_ACCEPTANCE_TEST_PLAN.md`, `08_CROSS_MODEL_PARITY.md`, `fixtures/` — verify behavior with no paid API calls.
11. `09_DELIVERY_AND_HANDOFF.md`, `10_QUESTIONS_AND_ASSUMPTIONS.md`, `12_REQUIREMENTS_TRACEABILITY.md`, `13_BUILD_AND_RELEASE_RUNBOOK.md` — reporting, gap management, contest deliverable traceability.
12. `prompts_for_later/` — purpose/contract reminders only, NOT instructions to build later modules now.

The files in `archive_previous_versions/` are a **historical record only**. Those include all previously supplied developer ZIPs. Do not open them by default, and never let old branding or instructions override active files.

## Frozen onboarding
Three screens, eight questions Q1–Q8; Q9 only when a problem-specific targeted clarification is genuinely needed. Q1 Q2 Q4 Q5 Q6 required. Q3 Q7 Q8 optional. Business profiles are saved and editable. Baseline retrieval is **catalog-only and zero-cost by default**.

## Discovery architecture
**Persistent business profile → user's problem → capability extraction → bounded query planning → internal catalog + replaceable external search → limited official-page extraction → structured claims with source provenance → identity resolution/deduplication → candidate list**. No invented ratings, fake third-party integrations, or unverified prices. The evaluator and integration recommender come later.

## Cost/security and honesty
The organizer issued an OpenRouter credit budget of **$25**. The key was previously visible in a screenshot and must be **rotated/revoked before use**. This archive excludes the screenshot and any live keys. Use mock mode by default and explicit flags for live calls. `$20` is the proposed **application-level spend target** with a `$5` reserve, not a provider hard limit; use provider-side restrictions where available. Search results and vendor claims are untrusted and must not be treated as verified without corroboration. Never claim real deployment/test success without execution evidence.

## Output expected from the coding AI
A runnable repository: `frontend/`, `backend/`, `supabase/migrations/`, `tests/`, `docs/`, secret-free `.env.example`, README with mock-mode startup and live-mode configuration, programmatic verification results, documented constraints, and the Phase-2 candidate handoff contract. The package you are reading is **NOT** that app; it is the detailed instructions to build it.

## Cross-model parity
ChatGPT, Claude, and Gemini need not generate identical code. They must implement the **same onboarding text/logic, endpoints/schema semantics, discovery state transitions, evidence rules, and mock acceptance scenarios**. Compare their behavior using `fixtures/scenarios.json` and the test plan, rather than comparing screenshots alone.
