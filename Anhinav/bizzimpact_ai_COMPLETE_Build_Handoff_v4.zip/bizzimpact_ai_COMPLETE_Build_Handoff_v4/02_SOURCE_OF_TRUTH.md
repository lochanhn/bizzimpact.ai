# Source of truth, precedence, frozen decisions and change control

## Precedence
1. **Organizer's challenge PDF:** business goal, judging, timing, rules, ownership. Do not overwrite.
2. **Approved onboarding v1 machine-readable `questionnaire-spec`:** exact Q1–Q9 copy, required flags, options, 3 screens, conditional Q9. This overrides any conflicting prose or UI guess.
3. **Discovery architecture v2 HTML `architecture-spec`:** adopted system architecture, two discovery modes, extraction/evidence rules, defer later modules.
4. **OpenAPI v2 YAML + SQL v2 schema:** implementation interfaces and data structures. If they need small engineering-safe adjustments, preserve public semantics, document migration/API deltas, and update generated tests.
5. **This active handoff's implementation contract and test plan:** makes unfilled details testable; never changes the four authorities above.
6. **Fixtures:** synthetic test data; examples, not verified real products.

Where two documents at the same level disagree, use the precise machine-readable field for that concern, record the discrepancy and document the minimum-risk choice; do not silently rewrite.

## Frozen requirements
- User sign-in/onboarding with 8 exact standard questions on 3 screens; only Q9 conditionally.
- 5 required: Q1 Q2 Q4 Q5 Q6. 3 optional: Q3 Q7 Q8.
- After profile: lightweight catalog-only baseline, default 0 paid model/web calls.
- Problem triggers hybrid catalog + selective live discovery; source-backed product records; no ratings yet.
- Third-party marketing assertions are never independent verification.
- Explicitly separate per-business private data from public/shared product data.
- $25 supplied OpenRouter credit is budget, NOT a promise of unlimited functionality.

## Clarifications codified in v3 (not changes to questionnaire)
- Standardize the backend path prefix `/api/v1` from the OpenAPI's `servers` configuration.
- `existing_software_status` = `selected|none|unknown` remains semantically distinct; nullable optional values are not invented defaults.
- User **problem entry is not a ninth onboarding question**. Q9 is the only optional conditional question, preferably at problem-specific search when necessary.
- Discovery results must never be called a ranking/recommendation. Catalog order is retrieval order only.
- The HTML's query-planning suggestion of 3–5 queries is not a promise of 5 paid searches; enforce configurable MVP max=3 by default per architecture JSON.
- The vendor-side `openrouter:web_search` tool is **model-invoked**, so `max_search_queries=3` in *our planner* does not prove OpenRouter only ran three server calls. Inspect actual usage and stop further requests when budget low.
- The SQL migration is a **reference**: migration idempotency, triggers, security policies, indexes and seeds require actual deployment checks; keep schema-compatible where possible.
- The mock/demo catalog contains **synthetic fictional entries clearly labeled**, never pretend they are real third-party recommendations.
- A confirmed canonical product is not the same as a confirmed price or integration: verification is per claim.

## What is still a decision or human configuration
- Actual Supabase project URL/anon key/server secret, OpenRouter replacement key, chosen model ID, deployment domains.
- Whether judge demo will be seeded email login, limited server-issued demo session, or anonymous read-only preview; must never grant unbounded paid calls.
- Vendor web-search tool usage restrictions and provider account feature availability.
- Real market research for any live catalog entries. Never invent these from fixtures.
- A real deployment URL depends on hosting/platform/account permissions.
