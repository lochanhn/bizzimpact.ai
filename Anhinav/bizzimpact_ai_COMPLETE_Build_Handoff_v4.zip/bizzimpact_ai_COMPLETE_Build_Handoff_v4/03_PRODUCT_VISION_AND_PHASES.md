# Entire product context & phased delivery

## Product
**Name:** bizzimpact.ai  | **Audience:** nontechnical small business owners, including restaurants, cafés, HVAC, landscaping, retail and service providers.

**Business question:** 'I have a business problem. Which existing AI solutions fit my business, how can I compare them responsibly, and how can I adopt one or more of them?'

**Not our product:** an AI receptionist, a scheduling chatbot, a demand forecaster, or one-off marketing generator. Those can be cataloged *vendor tools*, not the core platform.

## Why three modules
1. Discovery: *What actual AI products exist that plausibly address my need?* Business onboarding → normalized capability taxonomy → catalog+external search → evidence-backed candidates. **Build now.**
2. Review/evaluation: *Which discovered options suit this business best?* Define defensible multi-criteria metrics beyond crowd reviews; quantify pricing, capability coverage, integration claims, adoption complexity, uncertainty and weighted user constraints; separate tool quality from individualized suitability. **Future prompt/spec; not now.**
3. Multi-tool integrations/adoption: *Do selected tools work together and how would we implement them?* Compatibility evidence, handoff/workflow design, cost of combination, guided setup and later optional integrations. **Future prompt/spec; not now.**

## Future interoperability boundaries
At end of phase 1 produce:
```
DiscoveryResult {
  run_id: UUID,
  business_id: UUID,
  business_profile_snapshot: object (private, restricted),
  problem_summary: string,
  required_capabilities: string[],
  candidates: Array<{
    tool_id: UUID, name: string, official_url: string,
    ai_classification: 'ai_native'|'ai_enabled'|'non_ai_complement'|'unverified',
    matched_capabilities: string[],
    retrieval_channels: string[],
    claims: Array<{claim_type, claim_key, claim_value, source_url, observed_at, verification_state}>,
    unknowns: string[], warnings: string[]
  }>,
  discovery_status: 'completed'|'partial'|'failed',
  generated_at: ISO8601
}
```
Actual wire API structure remains the supplied OpenAPI v2. This illustration describes future integration data, NOT a request to modify the public API contract.

Phase 2 can consume candidate records and create a **separate** rating/assessment entity. Phase 3 can consume selected candidates and validated integration claims to build an adoption plan. Neither future phase is allowed to rewrite original evidence or claim direct vendor connections without confirmation.

## Organizer's scoring / delivery context
50-point rubric: research 10; MVP 30 (small-business applicability 10, architecture/scalability 10, UX 10); demo/presentation 10. Ten-minute video, accessible prototype link; up to 10 finalists; finalists present Nov 17, 2026. Original document states that submission IP belongs to UMD: team should read organizer terms before incorporating third-party proprietary work. Verify exact logistics in the included challenge PDF. **Submission deadline: Sun Nov 8, 2026, 11:59 p.m.**

## 16-week concept (presentation only for this hackathon)
Weeks 1–4: validate verticals/user research and refresh tool catalog/evidence. Weeks 5–8: rigorous evaluation metrics, baseline benchmarking and human review. Weeks 9–12: verified integration graph, workflow templates and cost modeling. Weeks 13–16: usability testing, monitoring, partner feedback, hardening, and responsible deployment plans. These are illustrative milestones, not current scope or guaranteed outcomes.
