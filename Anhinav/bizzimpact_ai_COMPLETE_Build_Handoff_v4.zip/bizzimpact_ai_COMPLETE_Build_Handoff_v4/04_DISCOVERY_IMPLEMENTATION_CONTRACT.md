# Discovery implementation contract — engineering checklist

## Required components
1. `ProfileController`: Supabase identity; profile create/read/update; canonicalize industry+subtype, employee band, country/region, software names/status, priorities (max 3), budget, optional channels.
2. `CapabilityMapper`: fixed seed vocabulary of 11 terms from architecture HTML and `capabilities` table. Do not invent arbitrary capability IDs in model output.
3. `BaselineDiscoveryService`: pure catalog lookup (industry/priority → tags) with **no OpenRouter/web call** by default; upto 6 retrieved tool records or useful empty state.
4. `ProblemInterpreter`: receives immutable profile snapshot + user's 10–2000 char problem; returns validated structured intent with goals, required/optional capabilities, explicit vs inferred requirement flags, one clarification question if material.
5. `QueryPlanner`: deterministic 3-query default: capability-first, contextual industry or cross-industry synonym, integration-specific only when actual existing software is selected; diversify instead of copying user's prose.
6. `CatalogSearchProvider`: SQL tag and keyword search, keyed by stable taxonomy IDs; optional vector retrieval only if tested.
7. `SearchProvider`: swappable raw `SearchHit` results. `OpenRouterSearchAdapter` is a best-effort model-controlled web search adapter; if it cannot return auditable raw candidates, surface failure/unknown. Can swap deterministic provider in future.
8. `PageFetcher`: safe official-page retrieval adapter; SSRF protections, rate/size/timeouts, redirect validation. Do not treat any extracted external text as trusted instruction.
9. `ProductNormalizer`: identifies actual vendor product, normalizes URL/domain and product name; avoid merging distinct products from same company.
10. `ClaimExtractor`: returns typed claims, `source_url`, bounded supporting evidence excerpt, `observed_at`, `verification_state`; no unsupported AI, price or integration claim.
11. `DiscoveryOrchestrator`: persist status transitions and candidates; partial result fallback; costs/errors/logging; idempotent retries where feasible.
12. `CandidateResults`: frontend user view with retrieval, evidence status, unknowns and accessible links; NO scores or 'best-for-you'.

## Two modes and state diagram
**Baseline** after onboarding/profile edit: Q1+Q7(+Q6) → normalize → search seeded catalog → up to 6 exploratory results; 0 paid calls. `GET /tools/{id}` shows evidence and provenance only.

**Problem search**: `queued → parsing → [needs_clarification → parsing] → catalog_search → [web_search] → enriching → completed|partial|failed`. `needs_clarification` is a resumable nonterminal state; skip is allowed. Each run stores the exact profile snapshot. If live web disabled, mark `partial` or `completed catalog-only` honestly with a warning; never imply independent live discovery.

## Query planning specifics
- User intent first: 'missed calls' → `ai_voice_receptionist`, `lead_capture`, perhaps `appointment_scheduling` if text implies it.
- Capability-first: `AI voice receptionist call answering small business`.
- Industry contextual: `AI receptionist for landscaping service company`.
- Integration only if profile has selected software and the integration is relevant, e.g. `AI receptionist Google Calendar integration` (do NOT assume Gmail integrates because Google Calendar does).
- Omit customer names, emails, phone numbers, exact street address, credentials, financial numbers not required by the query.
- No strict price exclusion at discovery: budget is contextual metadata for future review.

## Product eligibility / evidence
A candidate requires plausible real product identity, official domain or justified unresolved domain status, relevant capability, AI claim if AI-classified, and traceable discovery provenance. If only a directory/blog names a product, keep `provisional/evidence_pending`; don't set `confirmed` until at least a vendor-based product identity/capability claim is documented. Third-party assertions remain `third_party_reported`. If pricing is unavailable, use `null`, not `$0` or an invented figure. Dedupe by canonical product key (normalized product name + official vendor domain); maintain multiple source URLs and discovery channels.

## API and storage
Source-of-truth contracts: `references/impact_ai_discovery_openapi_v2.yaml` and `references/impact_ai_discovery_schema_v2.sql`. Respect `BearerAuth`, owner-scoped operations, and `/api/v1` prefix. Distinguish `POST /businesses` from `PUT /businesses/{business_id}/profile` and `POST /discovery/runs` from polling `GET /discovery/runs/{run_id}`. Persist source per claim, not only per tool. Use migration revisions where production SQL needs safe fixes, and update tests accordingly.

## API invariants (check in automated tests)
- Q6 `none` or `unknown` must have an empty selected software list; exactly one status. Q7 max 3; `Not sure yet` cannot coexist with a selected priority.
- `discovery_runs.owner_user_id` must match owning business on every create/read operation.
- Anonymous users cannot read private business profiles or runs.
- Every candidate has stable tool identity, provenance, and flags when verification is incomplete.
- Claimed capabilities and integrations require source evidence; `verified_candidate` is not a quality score.
- Baseline and live paths share a consistent serialized product representation.

## Demo definition
Demonstrate one landscaping case end-to-end and a second restaurant or retail case showing industry-agnostic capability mapping. Show a tool discovered from web that is not preseeded **only if actual live discovery ran**; otherwise label the operation simulated. Screenshots/presentation must not present fixture/demo vendors as verified real products.
