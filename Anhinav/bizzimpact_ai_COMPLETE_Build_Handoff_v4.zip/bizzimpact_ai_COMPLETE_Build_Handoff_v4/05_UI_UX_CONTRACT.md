# UX contract: consistent user-visible behavior across models

## Principles
Nontechnical small-business owners must understand the app on first use. Plain language over ML jargon; explain why information is requested; progressive disclosure, 3 screens, contextual help. Responsive widths, accessible labels/keyboard navigation, visible focus, adequate contrast, no dark patterns. Demo mode clearly and persistently labeled.

## Routes and required content
- `/`: bizzimpact.ai landing, proposition ('Find the right AI tools for your small business'), Start and Demo buttons, **no false testimonials**.
- `/auth`: Sign up / Sign in using Supabase. Clear failure messages. Demo option is server-limited.
- `/onboarding`: 3-step progress indicator; Q1–Q4, Q5–Q6, Q7–Q8 per source. Save progress where feasible; Back/Next. Q1 has searchable industry and subtype; Q2 short description; Q3 customer type; Q4 size; Q5 country+region; Q6 software suggestions with custom add, mutually exclusive None / Not sure; Q7 max3, 'Not sure' exclusive; Q8 total new AI software/month. Optional Q3/Q7/Q8 can be skipped. No customer-specific personal data requested.
- `/dashboard`: short business summary; 'Edit business profile'; broad category suggestions and **catalog-only baseline**; primary input **'What would you like help with today?'**, 10–2000 chars, visible validation.
- `/discovery/[runId]`: progress indicator with true status; optional Q9/one clarification with skip; candidate cards with official site, capabilities, source evidence/verification, unknowns; error/partial fallback; never show a fake star rating.
- `/tools/[toolId]`: name, official site, summary, supported capabilities with linked source claims, integration/pricing claims **only when documented**, last-observed date, unknowns; disclaimer that vendor claims are not independently tested.
- `/profile`: editable Q1–Q8 answers and optional contact channel if known; saved-state feedback.

## Presentation uniformity
Use restrained, accessible design: neutral backgrounds, clear type hierarchy, blue/teal informational accents, no unrelated decorative illustrations. Keep navigation and labels named above. The exact CSS need not match across models; functional parity is mandatory.

## Empty, loading and failure states
- Zero baseline products: 'We can look for tools after you describe a specific problem'; do not fake cards.
- Live provider unavailable: 'Live discovery is unavailable right now; these are catalog results only.'
- Rate/budget exceeded: 'Live searching is paused; existing catalog results remain available.'
- Unknown integration: 'Integration not verified', not 'Compatible'.
- Tool claim source missing: do not show confirmed tag.
- Discovery state stops at failure or completes; no infinite spinner.
- Demo fixture vendor: prominently mark 'Synthetic demonstration product' on cards/detail.

## Acceptance
Test keyboard-only onboarding, selection exclusivity, no mandatory optional Qs, state persistence after reload, safe role-appropriate menu, logged-out access denied, mobile viewport, accessible error notices.
