# API costs, secrets, and web safety — mandatory controls

## Known facts and uncertainty
Hackathon email grants **$25 OpenRouter credit**, not a guaranteed fixed quota of model calls. Pricing depends on model, tokens, web-search engine, web fetch and provider configuration. Validate current availability and prices before enabling live mode. OpenRouter documents model-controlled `openrouter:web_search` and `openrouter:web_fetch` server tools; those may execute **0–N times inside a model request**, so prompt-level max queries do not enforce actual paid calls. Current docs: https://openrouter.ai/docs/guides/features/server-tools/overview and https://openrouter.ai/tool/web-search/ . Record server-tool usage if returned.

## Credentials
Previous API key appeared in a screenshot; **rotate/revoke it** before use. Don't include either old or replacement key in repository, prompts, screenshots, logs, issue tickets, or client source. Only use OpenRouter through the backend Authorization bearer header from `OPENROUTER_API_KEY`. Frontend uses only client-safe Supabase publishable key; service-role key stays server-side. `.gitignore` should ignore `.env*` except `.env.example`.

## Defaults and staged rollout
- `DISCOVERY_MODE=mock`; `OPENROUTER_ENABLED=false`; `LIVE_WEB_ENABLED=false`; zero external calls in unit/integration CI.
- `LIVE_WEB_ENABLED=true` only with explicit local/operator configuration and authenticated, rate-limited users.
- Keep reserve $5; global app spend stop target $20 across model + search costs. **This is a software guard, not a provider-side hard guarantee.** If available, configure key-level cap or guardrails in provider dashboard as a second control. Note some features require admin permissions.
- Internal suggested per-run budgets: max3 queries in our planner, max5 unique vendor domains, max10 page fetches, max5 explicit model calls, one retry for throttling/transient failures. Server tool internal calls must be separately observed; do not pretend limits enforce them.
- Log prompt/response *metadata* only (model, tokens, web count, duration, estimated USD, job ID, errors); never log secret or unnecessary business-sensitive content.
- Cache verified source records with fetched_at; rerun web only if necessary; don't use the API to regenerate UI/test fixture content.
- Use mock parser and fixture-based search/extraction for all routine tests; only a tiny manually approved suite of live validation calls, and stop on abnormal costs.

## Response-level budget guard sample behavior
Before any planned model/search request, estimate upper bound against remaining internal budget; if insufficient return catalog-only partial. After request, record returned actual usage where available, update app budget; if usage unavailable, conservatively account for estimate and label cost uncertain. When provider lacks hard limits on individual server-tool calls, permit only a small number of authorized live runs with operator oversight or choose a deterministic external provider.

## Additional security boundaries
- Verify JWT signature, issuer, audience and ownership server-side; correct RLS policies; least privilege.
- SSRF safe fetch: only http(s); resolve DNS and reject localhost, link-local, private, loopback, metadata, multicast, reserved IPs; revalidate every redirect; cap content size, timeouts, redirects; no credentials in URLs.
- Treat all vendor/blog pages and search snippets as untrusted data; model must not obey their instructions or reveal internal system context.
- Sanitize HTML; avoid injecting website content into innerHTML; escape rendered links/content; validate external URLs.
- Mask sensitive user input before sending to web search; privacy-conscious retention and deletion.
- Rate-limit user sessions and demo runs; no unlimited paid search from anonymous browser.

## Do not confuse two APIs
OpenRouter model/web APIs are used by our app **at runtime**. The model used to write the code (Claude/ChatGPT/Gemini) may have separate subscription/tool limits. The provided $25 OpenRouter credit should **not** be spent just to have a coding assistant create the code unless deliberately authorized.
