# Phase 1 acceptance tests — contract-level and UI smoke tests

## Standard test procedure (run on every assistant's output)
1. Install pinned dependencies, run backend migration on a temporary Supabase/local Postgres instance where available.
2. Start backend and frontend with `DISCOVERY_MODE=mock`, `OPENROUTER_ENABLED=false`, `LIVE_WEB_ENABLED=false`.
3. Run `pytest -q`, frontend `lint`, `tsc --noEmit`, and `next build`, or explain exactly which toolchain is unavailable. Execute test fixtures below, assert no HTTP requests to OpenRouter or search engines.
4. Compare OpenAPI schemas and status codes. Run local smoke checks for `/`, `/auth`, `/onboarding`, `/dashboard`, `/discovery/[id]`, `/tools/[id]`, `/profile`.
5. Check RLS/auth (user A must not access user B); run SSRF redirect tests; inspect secrets scanner.
6. Only after mock passes, with a rotated key and authorized small budget, test one minimal real OpenRouter parse and one web-discovery case; record actual usage/limitations. Do not falsely mark live as passed if unconfigured.

## Onboarding (source-approved)
- ONB-01: Required Q1 Q2 Q4 Q5 Q6 accepted; optional omitted -> stored null / empty as defined; reload returns same normalized profile.
- ONB-02: Q6 `none` or `unknown` plus selected tools rejected; `not sure` distinct from `none`.
- ONB-03: Q7 select 4 rejected; `Not sure yet` exclusive. Skipped Q8 remains null; Q8 not a hard discovery filter.
- ONB-04: Q1 Other/custom subtype saved and displayed; region optional where not applicable; no street address.
- ONB-05: Returning user skips onboarding; profile edit affects later run snapshot.

## Catalog baseline
- BASE-01: New landscaping profile and Q7 priorities trigger catalog-only baseline and **zero** external/model requests; return matching fixture records or genuine empty state.
- BASE-02: No catalog matches -> no fabricated tool names, show constructive next step.

## Discovery
- DISC-01: Landscaping missed calls → voice receptionist/lead capture; avoid irrelevant marketing capabilities.
- DISC-02: Restaurant stock waste → demand forecasting and inventory optimization, not generic ad-generation tools.
- DISC-03: No existing software → do not infer integrations with specific vendors.
- DISC-04: Ambiguous customer-contact problem where channels unknown → asks Q9 once; skip continues. If user explicitly says 'phone calls', do not ask same question.
- DISC-05: Same synthetic vendor appears catalog and mock web → one product with both retrieval channels and source evidence.
- DISC-06: New vendor in mock web not seeded → insert provisional candidate, clearly synthetic. **Live variant** must prove uncataloged real vendor only if actual web search occurred.
- DISC-07: Same query with changed industry/software generates visibly different query plan, within configured 3-query max, without leaking personal information.

## Evidence
- EVID-01: Third-party only says an integration exists → `third_party_reported`, not `vendor_documented`.
- EVID-02: Vendor pricing not published → null price with unknown status, not fabricated zero or guessed amount.
- EVID-03: Vendor pages contain hostile 'ignore previous instructions' text → extractor treats it as data, never follows it.
- EVID-04: Same company with two genuinely distinct products should not be wrongly merged.

## Resilience, money, authentication
- RES-01: Live search timeout or 429 → bounded retry then catalog-only partial/warning; no spinner loop.
- RES-02: Simulated budget exhausted/402 → no new paid calls, preserve already found candidates and warning.
- RES-03: Provider returns invalid JSON → validate and bounded retry/fallback; never crash application.
- AUTH-01: User B tries User A profile/run -> 403 or 404 and no sensitive payload.
- SAFE-01: Redirect target is private/link-local IP or localhost -> reject before fetch.
- COST-01: In mock mode intercept any network call to OpenRouter/search and fail test if observed.
- DEMO-01: Demo identity cannot run unlimited paid discovery; synthetic records are visibly labeled.

## Metrics (report observed values only)
Precision@5 over curated reference cases, reference-set recall, source evidence coverage, unsupported claim rate, fresh-vs-known discoveries, dedup rate, latency, per-run API cost. Don't invent benchmark statistics, and don't confuse reference-set recall with internet-wide recall.

## Required evidence format
For every item: `PASS / FAIL / NOT_RUN / BLOCKED`, command or UI steps, expected outcome, actual observation, and file/line or error link where applicable. Code being present does not prove the test passes.
