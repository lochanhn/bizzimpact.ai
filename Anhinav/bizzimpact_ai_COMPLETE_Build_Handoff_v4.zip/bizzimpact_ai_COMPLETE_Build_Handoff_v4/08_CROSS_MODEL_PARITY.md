# How to get comparable implementations from ChatGPT, Claude, Gemini

## The truth
You cannot **guarantee identical source code, feature completeness, visual appearance, or deployment success** from independently prompted models. You can strongly improve **functional consistency** by giving each the same immutable input files, exact stack, API and database contracts, synthetic fixtures, security constraints and tests. Also give each access to equivalent coding/file/terminal capabilities, not just a plain chat window.

## Run three isolated experiments
- Start each AI with a new empty repo/workspace. Do not give one AI another AI's completed code unless you intentionally want refinement rather than independent comparison.
- Upload **the exact same ZIP** and paste **the same master prompt** without paraphrase.
- Use the same environment/runtime major versions and same open-source dependencies where feasible. Fix the same chosen OpenRouter model slug if doing a live test.
- Do NOT supply the secret via chat to any assistant. Configure environment secrets yourself. Rotate exposed key first.
- First compare in **mock mode** with identical fixtures, before any live calls. Live results are nondeterministic, change with the web, and may incur different costs.
- Require every AI to run the same acceptance script and produce `09_DELIVERY_AND_HANDOFF.md` style report.

## Normalize these observable outputs
- Same 3 questionnaire screens, Q1–Q9 text/options/rules.
- Same required API methods, field names, status codes and response schemas from OpenAPI.
- Same database semantic tables and RLS ownership controls.
- Same two modes and status transitions.
- Same 11 seed capability IDs, same fixtures, same expected clarification behavior.
- Same evidence labels; never infer a claimed integration is independently verified.
- Same mock-mode no-cost behavior and same budget caps/feature flags.
- Same set of deferred Phase 2/3 functionality.

## Comparison matrix to fill
| Check | ChatGPT | Claude | Gemini |
|---|---|---|---|
| Frontend builds | | | |
| Backend tests pass | | | |
| API contract tests | | | |
| 8-question onboarding preserved | | | |
| Conditional Q9 | | | |
| Catalog baseline no paid calls | | | |
| Hybrid discovery mocked | | | |
| Actual live web discovery verified | | | |
| Evidence provenance correct | | | |
| Cross-user authorization tested | | | |
| Demo without account friction | | | |
| Live usage/cost recorded | | | |
| Deployment link working | | | |

**Most important:** score **tested behavior** rather than how confident or elaborate the AI's written answer looks.

## Common failure signals
- Says 'application complete' but outputs only plan/snippets.
- Uses fake products as if real, or claims fresh internet data without a live search.
- Makes OpenRouter calls directly in the browser or embeds secret.
- Skips JWT ownership/RLS to make the demo easier.
- Implements a rating engine before source-backed discovery works.
- Automatically retries search in loops; drains credits.
- Bypasses open API contracts and invents endpoints.
- Displays a fake '100% compatible' label without independent source.

## Recommended selection process
Choose the implementation with highest passing behavior/security/maintainability—not the model name. You may take the best tested repository as the baseline and hand it to a second model for independent review, but that is a separate collaborative workflow, not identical independent builds.
