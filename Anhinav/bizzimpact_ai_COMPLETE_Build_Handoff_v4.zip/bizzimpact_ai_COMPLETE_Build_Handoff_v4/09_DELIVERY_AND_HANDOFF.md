# Required delivery report from the coding AI

At completion, return:

1. **Repository tree** with real paths and build instructions. State which files were newly created or modified.
2. **Setup:** versions and copy/paste commands for frontend, backend, migrations, seed, tests, mock/demo, and live settings. Use placeholders for secrets.
3. **Screens/flows:** auth, 3 onboarding screens, profile edit, dashboard baseline, problem search, clarification, progress, candidate results, detail.
4. **API:** list of implemented paths with status codes; contract differences vs reference OpenAPI.
5. **DB/RLS:** actual migrations run (or 'not run') and proof of cross-user isolation test.
6. **Provider status:** mock vs OpenRouter live vs web search/fetch. If live isn't configured, explicitly say untested, not functional.
7. **Costs:** exact observed paid calls and reported cost/usage; zero in mock mode; unknown amounts labeled as unknown.
8. **Test report:** table containing PASS/FAIL/NOT_RUN/BLOCKED for all acceptance IDs and commands.
9. **Screenshots or deployed URL**, only if actually created/verified.
10. **Known limitations** with remediation priorities.
11. **Future handoff:** shape for `DiscoveryResult` and interfaces reserved for evaluation and integration (no scoring logic deployed).
12. **Security:** confirm no credential/secret appears in committed files; never print API keys.

### Definition of done
A reviewer can clone/extract repo, configure mock mode, run tests, and use complete onboarding → business profile → catalog baseline → problem input → discovery run → evidence-backed candidates without an OpenRouter key. Live behavior can only be marked complete once a real call was performed with a rotated key and documented cost/response (and can then be disabled again to conserve budget).
