# Missing external configuration (nonblocking) and assumptions

We have deliberately **not** requested additional user inputs before designing this package.

Decisions a human must eventually configure:
- Supabase project credentials and DB connection, auth redirect URLs, RLS migration access.
- Replaced/rotated OpenRouter API key, explicit selected model ID, live search/fetch availability, allowed search engine pricing.
- Hosting target URL(s), demo login strategy, provider-side spend cap and billing permissions.
- Which real software tools can be included after researching official product sites.

Assumptions that coding AI may implement now and later revisit:
- Mock mode is fully functional with synthetic fixtures; its purpose is engineering correctness, not market verification.
- Next.js App Router + FastAPI persistently hosted + Supabase Auth/Postgres as frozen choices.
- App-level daily/global budget checks are best effort; provider-enforced caps need human configuration.
- OpenRouter web-search server tools may not expose raw deterministic search hits; adapt interface honestly and keep swap option.
- In normal sign-in users own their profiles; in judge demo access is limited and seeded.
- The time target '2 minutes' for onboarding is aspirational, not empirically measured.

A coding assistant should proceed on local code without demanding credentials. It may request human intervention for **actual** provider setup/deployment only, not demand the secret itself in chat.
