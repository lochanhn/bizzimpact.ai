# v4 Decisions and Overrides — normative addendum

This file clarifies brand/context and package handling. It **does not change** the approved questionnaire, official challenge, or underlying technical contracts.

## Decision log (locked for Phase 1)

| ID | Decision | Reason and expected behavior |
| --- | --- | --- |
| V4-01 | **App name and visible brand:** bizzimpact.ai | User updated project naming. `impact.ai` in older specs is its earlier name, **not a second product**. Use `bizzimpact.ai` in UI, README, example domains, metadata; leave historical source filenames unchanged. Do not assume the domain is owned/deployed. |
| V4-02 | Phase 1 only: business onboarding + discovery | Later evaluation/review metrics and multi-tool integration/adoption are future modules and must not be accidentally implemented or displayed as working features. |
| V4-03 | Freeze approved Q1–Q8 + optional Q9 | Copy the original `questionnaire-spec` from the approved HTML; any duplicates must match it. |
| V4-04 | Baseline after onboarding uses internal catalog only by default | Saves scarce API funds; problem-specific input triggers hybrid discovery. |
| V4-05 | Hybrid catalog + web discovery, replaceable providers | OpenRouter is for model processing and *potentially* provider-managed web tools when available, but must not be assumed a conventional, fixed-price web crawler. |
| V4-06 | Explicit evidence and uncertainty | Vendor marketing descriptions are claims, not independently verified performance. Unknown pricing/integration remains unknown. |
| V4-07 | Judge/demo mode safe by default | Zero-cost fixture mode must be identifiable to judge; never disguise fake vendors as real. No unrestricted anonymous paid search. |
| V4-08 | Protect team $25 OpenRouter budget | Default mock; explicit live flags, usage logging, caution that in-app spending limits aren't provider-side hard guarantees. |
| V4-09 | Security-first credentials | Exclude original key screenshot; rotate previously exposed key; backend secrets only. |
| V4-10 | Docs before code; actual code as delivery | These files describe the desired app; the coding model must create and test the real repo and not report successful deployment without evidence. |

## Precedence when materials conflict

1. Organizer's original challenge PDF governs official challenge requirements.
2. User-approved onboarding source `references/AI_Small_Business_Discovery_Onboarding_Spec_v1.html` (`questionnaire-spec`) governs question text, choice sets, field rules.
3. This v4 decisions file governs **updated branding/packaging/scope and security clarifications** only.
4. Adopted discovery architecture `references/impact_ai_Onboarding_and_Discovery_Architecture_v2.html` governs design semantics.
5. Reference OpenAPI/SQL plus `04_DISCOVERY_IMPLEMENTATION_CONTRACT.md` govern technical behavior, subject to compatibility-preserving corrections documented explicitly.
6. Remaining v4 root documents, then fixtures, then historical archives (provenance only).

If a technical contradiction prevents running the app, select the smallest secure and backwards-compatible correction, add a regression test and document the delta in the final handoff. Never silently change an approved user question or make source-free product assertions.

## What we have *not* decided
- Final OpenRouter model slug; which models/features the team's actual key allows; confirmed per-call prices and provider usage caps.
- Real hosting accounts, Supabase project configuration and deployed domain.
- Exact reviewed vendor catalog; synthetic examples are for testing only.
- Formal evaluation metric weights and thresholds (Phase 2).
- Multi-tool graph/compatibility rules and deployment automation (Phase 3).

These are not licenses to invent facts. Build the no-cost local/mock path and leave human-supplied external settings configurable.
