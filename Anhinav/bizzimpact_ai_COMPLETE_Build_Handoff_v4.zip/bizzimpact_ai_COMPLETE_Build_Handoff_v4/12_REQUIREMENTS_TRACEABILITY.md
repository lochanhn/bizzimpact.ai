# Challenge-to-product requirements traceability

**Source:** `references/AI_for_Small_Business_Hackathon_Fall_2026_The Challenge.pdf`, two pages. Distinguish official organizer requirements from our architectural choices below. Read the PDF directly for authoritative wording.

| Official challenge statement | Location | Current design response | Build status |
| --- | --- | --- | --- |
| Design and build a platform for small businesses to discover, compare and adopt AI tools | p.1, The Ask | Three modules: discovery, evaluation/review, integration/adoption | Discovery only now; others later |
| Serve nontechnical small-business owners | p.1 | Guided 3-screen onboarding, natural-language problem, explained results | Phase 1 |
| Tools should be discovered by the platform | p.1, Angie’s List comparison | Hybrid curated catalog + live query-based discovery, extraction, deduplication | Phase 1 |
| AI-tool ratings should go beyond reviews | p.1 | Evidence-preserving records and future personalized metrics | Phase 2; NO numeric ratings in Phase 1 |
| Multiple tools may need integrating | p.1 | Integration claims preserved, future multi-tool graph and adoption planner | Phase 3; NO live vendor integration in Phase 1 |
| 10-minute video: MVP, approach, 16-week plan, technical feasibility/value | p.1 | Demonstrate end-to-end discovery, tests/provenance, presentation roadmap | Final contest submission (not supplied here) |
| Prototype link accessible to judges | p.1 | Demo-safe link and onboarding flow, protect paid search | Must deploy separately |
| Finalists present Nov 17 | p.1 | Future presentation planning | Conditional |
| Team size 2–3, only one team per participant | p.2 | Organizer compliance reminder | Human/team responsibility |
| Research quality 10/50 | p.2 | Credible search, product source references, discovery validation | Research/demonstration |
| MVP applicability 10/50 | p.2 | Industry-adaptive profile and realistic small-business constraints | Phase 1 groundwork |
| Architecture/scalability 10/50 | p.2 | Normalized database, service abstractions, replaceable providers | Phase 1 |
| UX 10/50 | p.2 | Nontechnical onboarding, edits, results, clear loading/error states | Phase 1 |
| Demonstration/presentation 10/50 | p.2 | Test evidence and clear product story | Final contest presentation |
| Participation IP belongs to UMD under original terms | p.2 | Read terms; avoid proprietary code reuse without clearance | Human/legal review |

## Key honesty boundary
A **Phase 1 discovery-only build does NOT meet the complete full-platform vision**. It establishes the first module and data contracts for the other two. Do not falsely report that tool ratings beyond reviews or multi-tool integration are already implemented. For the hackathon video, explain transparently which parts are working and which are future scope.
