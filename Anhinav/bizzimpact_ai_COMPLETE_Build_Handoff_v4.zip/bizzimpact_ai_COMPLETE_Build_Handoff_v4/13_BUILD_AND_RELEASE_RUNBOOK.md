# Developer execution and release runbook

## For the code-writing AI

1. Read `00_START_HERE.md`, `01_MASTER_BUILD_PROMPT.md`, `11_V4_DECISIONS_AND_OVERRIDES.md`, then source-of-truth and all active requirements before coding.
2. Present an extremely short assumptions list **only for unprovided external credentials**, then proceed with a local mock-first build. Do not block on API keys or paid services.
3. Scaffold real repo: `frontend/`, `backend/`, `supabase/migrations/`, `tests/`, `docs/`, `.env.example`, `.gitignore`, `README.md`.
4. Implement API and UI exactly as the supplied OpenAPI and approved onboarding; document compatibility-preserving fixes.
5. Prove end-to-end **zero-credit** mock journey (start frontend/backend locally, fill questionnaire, save and edit profile, catalog baseline, describe problem, create discovery run, show status and evidence-backed mock results labeled simulated).
6. Prove direct API and frontend tests plus error/ownership cases. Don't claim tests that you did not execute.
7. Implement live OpenRouter and web adapters **disabled by default**. Test outgoing payload construction with mocked HTTP responses. Only call live services if operator explicitly enables and has configured rotated credentials.
8. Include usage logging and a manual way to check/disable live access before demo deployment. Do not enable public unmetered API access.
9. Validate judge preview with no account-verification barrier, if offered; preview is sandboxed and may not trigger paid discovery.
10. Deliver actual downloadable repo or workspace files, startup commands, real test outcomes, blockers, deployment steps/URL if verified and follow-on phase boundaries.

## Local setup checklist for human developer

- Node and Python versions supported by generated repo (actual versions chosen by coding agent and pinned).
- Supabase project created or a documented mock in-memory persistence fallback for no-account demo.
- `OPENROUTER_API_KEY` stored **only in backend environment/secrets manager** after previously exposed key is revoked and replaced.
- Default `OPENROUTER_ENABLED=false`, `LIVE_WEB_ENABLED=false`, `DISCOVERY_MODE=mock`.
- Explicit database migration and RLS verification prior to production use.
- Production frontend environment includes only public client-safe variables (no service-role or OpenRouter secret).
- Deployment must truly respond at the provided URL, with frontend/API CORS and auth ownership verified.
- Film and submit 10-minute video with proof-of-concept, approach, 16-week future work, and proof of feasibility/value; meet organizer's Nov 8, 2026 11:59 p.m. deadline.

## Common reasons to fail acceptance
- A dashboard showing hardcoded 'real' AI vendors without sourced data; wrong.
- An LLM generating plausible but fictitious prices/integrations; wrong.
- 'Integrated tools' shown as connected without actual vendor authorization; wrong.
- Passwordless judge demo accidentally having an unlimited paid-search button; wrong.
- Secrets present in JavaScript/client bundle, logs, Git, screenshots or README; wrong.
- All tests only mock API routes without exercising the UI; insufficient.
- App claims deployment without actually serving an accessible URL; wrong.
- AI stops at an architecture explanation rather than producing executable project; wrong.

## Contest stage reminder
The ZIP is an **implementation handoff**, not the app, and a Phase 1 demo is not the entire product. Final evaluation/review scores and multi-tool adoption details require later specs and implementation.
