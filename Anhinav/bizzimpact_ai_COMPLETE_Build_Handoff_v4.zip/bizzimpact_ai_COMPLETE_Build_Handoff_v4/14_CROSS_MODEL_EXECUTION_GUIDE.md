# ChatGPT, Claude and Gemini: same-input build comparison procedure

The goal is **functionally equivalent** implementations, not identical code files or UI pixels. Each environment must be coding-enabled (filesystem access, commands, install/build/tests); plain chat can only draft code, not verify it.

1. Create a separate empty workspace for each of the three models.
2. Upload identical `bizzimpact_ai_COMPLETE_Build_Handoff_v4.zip`.
3. Paste identical `01_MASTER_BUILD_PROMPT.md`, unchanged.
4. Set no paid API credentials initially. Run exactly the same synthetic scenarios from `fixtures/scenarios.json`.
5. Demand full source + actual build/test logs + endpoint contract conformity.
6. Record pass/fail under `08_CROSS_MODEL_PARITY.md`: onboarding, data persistence, baseline, discovery states, evidence, no fake tool claims, mock free path, API parity, security.
7. Keep the best **single repo** and use the other models as reviewers, rather than trying to merge incompatible generated architectures.

Potential variations that are *not* grounds for failure: internal service class names, CSS implementation, library versions compatible with contracts. Variations that ARE failures: missing Qs, different required-flag rules, unverified claims presented as verified, exposing API keys, skipping tests, simulating live discovery without disclosure, implementing future modules as fake completed features.
