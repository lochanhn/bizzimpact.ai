# Historical archives — do not treat as implementation authority
These ZIPs are included only to preserve **all earlier delivered documents and developer packs** requested by the user. They duplicate or predate the top-level documents. **Do not** merge conflicting instructions from these archives into the active specification, and do not recursively reprocess them as separate projects.

- `original_discovery_developer_pack_v2.zip`: former HTML+SQL+OpenAPI pack.
- `original_cross_model_build_handoff_v3.zip`: previous cross-model package.

The earlier project label `impact.ai` refers to the same project now called **bizzimpact.ai**. Keep historical filename spellings for citation and consistency; use the new name in the actual app.
