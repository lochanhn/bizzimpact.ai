# Synthetic fixtures
`questionnaire_approved_v1.json` is a verbatim extraction of the approved machine-readable questionnaire from onboarding HTML and is normative.
`scenarios.json` holds representative profiles and expected capability/clarification behavior for model-independent tests. Expected capabilities express a target baseline; additional supported capabilities may be reasonable if backed by the problem.
`synthetic_demo_catalog.json` contains **fictional DEMO products** hosted under reserved `example.org` names to avoid mistaking fixture vendors for live real products. The mock web duplicate must deduplicate with catalog product; mock web new product must remain provisional and clearly labeled synthetic. Do NOT send real HTTP requests to `example.org` for fixtures. Fixture IDs are fixed to make tests reproducible.
Use no external API calls for unit tests. Seed actual, verified products separately (source-backed) when available.
