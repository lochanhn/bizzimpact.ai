Visual renderings of the two-page official challenge PDF for convenient review. The original PDF in `references/` is authoritative. No API credential screenshots are included.
